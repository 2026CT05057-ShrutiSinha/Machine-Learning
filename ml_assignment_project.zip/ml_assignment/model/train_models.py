"""Customer campaign response prediction - 5 classifiers compared.
Run from the project root:  python model/train_models.py
"""
import os, warnings
import numpy as np
import pandas as pd
import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, roc_auc_score, precision_score,
                             recall_score, f1_score, matthews_corrcoef,
                             confusion_matrix)

warnings.filterwarnings("ignore")
SEED = 42
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "results")
os.makedirs(OUT, exist_ok=True)

# ---------------------------------------------------------------- 1. load
df = pd.read_csv(os.path.join(ROOT, "marketing_campaign.csv"), sep="\t")
print("Raw shape:", df.shape)

# ------------------------------------------------- 2. EDA / data quality
print("\nMissing values:\n", df.isna().sum()[df.isna().sum() > 0])
print("\nClass distribution (Response):")
print(df["Response"].value_counts())
print(df["Response"].value_counts(normalize=True).round(4))

sns.countplot(x="Response", data=df)
plt.title("Class distribution of target (Response)")
plt.savefig(os.path.join(OUT, "class_distribution.png"), dpi=150, bbox_inches="tight")
plt.close()

# ---------------------------------------------- 3. cleaning / engineering
# constant columns carry no information; ID is just an identifier
df = df.drop(columns=["Z_CostContact", "Z_Revenue"])
dups = df.drop(columns=["ID"]).duplicated().sum()
print(f"\nDuplicate customers (ignoring ID): {dups}")
df = df.drop(columns=["ID"]).drop_duplicates().reset_index(drop=True)

df["Age"] = 2014 - df["Year_Birth"]                       # data collected ~2014
df["Customer_Tenure_Days"] = (pd.Timestamp("2014-12-31") -
                              pd.to_datetime(df["Dt_Customer"], format="%d-%m-%Y")).dt.days
df = df.drop(columns=["Year_Birth", "Dt_Customer"])
df = df[df["Age"] < 100]                                  # impossible ages (born 1893/1899/1900)

# merge equivalent / junk marital categories
df["Marital_Status"] = df["Marital_Status"].replace(
    {"Alone": "Single", "Absurd": "Other", "YOLO": "Other"})

X = df.drop(columns="Response")
y = df["Response"]
print("\nShape after cleaning:", X.shape)

num_cols = X.select_dtypes(include="number").columns.tolist()
cat_cols = ["Education", "Marital_Status"]
num_cols = [c for c in num_cols if c not in cat_cols]

# ---------------------------------------------------- 4. train/test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=SEED, stratify=y)
print("Train:", X_train.shape, " Test:", X_test.shape)
print("Train positive rate:", round(y_train.mean(), 4), " Test:", round(y_test.mean(), 4))

# save raw test data for the repo (includes the target)
pd.concat([X_test, y_test], axis=1).to_csv(os.path.join(ROOT, "test_data.csv"), index=False)

# ------------------------------- 5. preprocessing (fit on train only via Pipeline)
def make_preprocessor(scale):
    num_steps = [("imp", SimpleImputer(strategy="median"))]
    if scale:
        num_steps.append(("sc", StandardScaler()))
    return ColumnTransformer([
        ("num", Pipeline(num_steps), num_cols),
        ("cat", OneHotEncoder(handle_unknown="ignore", drop="first"), cat_cols),
    ])

# scaling matters for distance/gradient based models (LR, kNN, NB-optional); trees don't need it
models = {
    "Logistic Regression": (True,  LogisticRegression(max_iter=1000, random_state=SEED)),
    "Decision Tree":       (False, DecisionTreeClassifier(max_depth=5, min_samples_leaf=10, random_state=SEED)),
    "kNN":                 (True,  KNeighborsClassifier(n_neighbors=7)),
    "Naive Bayes":         (True,  GaussianNB()),
    "Random Forest (Ensemble)": (False, RandomForestClassifier(n_estimators=300, random_state=SEED, n_jobs=-1)),
}

# ------------------------------------------------------- 6. train + evaluate
rows, cms = [], {}
for name, (scale, clf) in models.items():
    pipe = Pipeline([("prep", make_preprocessor(scale)), ("clf", clf)])
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    proba = pipe.predict_proba(X_test)[:, 1]
    rows.append({
        "ML Model Name": name,
        "Accuracy":  accuracy_score(y_test, pred),
        "AUC":       roc_auc_score(y_test, proba),
        "Precision": precision_score(y_test, pred, zero_division=0),
        "Recall":    recall_score(y_test, pred),
        "F1":        f1_score(y_test, pred),
        "MCC":       matthews_corrcoef(y_test, pred),
    })
    cms[name] = confusion_matrix(y_test, pred)
    fname = name.split(" (")[0].lower().replace(" ", "_") + ".pkl"
    joblib.dump(pipe, os.path.join(ROOT, "model", fname))

res = pd.DataFrame(rows).set_index("ML Model Name").round(4)
print("\n", res.to_string())
res.to_csv(os.path.join(OUT, "metrics.csv"))
with open(os.path.join(OUT, "metrics.md"), "w") as f:
    f.write(res.reset_index().to_markdown(index=False))

# ------------------------------------------------------------ 7. visuals
ax = res.T.plot(kind="bar", figsize=(12, 6), width=0.8)
ax.set_title("Evaluation metrics by model"); ax.set_ylabel("Score"); ax.set_ylim(0, 1.05)
plt.xticks(rotation=0); plt.legend(loc="lower right", fontsize=8)
plt.savefig(os.path.join(OUT, "metrics_by_metric.png"), dpi=150, bbox_inches="tight"); plt.close()

ax = res.plot(kind="bar", figsize=(12, 6), width=0.8)
ax.set_title("Model comparison across metrics"); ax.set_ylabel("Score"); ax.set_ylim(0, 1.05)
plt.xticks(rotation=15); plt.legend(loc="lower right", fontsize=8)
plt.savefig(os.path.join(OUT, "metrics_by_model.png"), dpi=150, bbox_inches="tight"); plt.close()

plt.figure(figsize=(9, 5))
sns.heatmap(res, annot=True, fmt=".3f", cmap="YlGnBu")
plt.title("Metrics heatmap"); plt.savefig(os.path.join(OUT, "metrics_heatmap.png"), dpi=150, bbox_inches="tight"); plt.close()

fig, axes = plt.subplots(1, 5, figsize=(22, 4))
for a, (n, cm) in zip(axes, cms.items()):
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, ax=a)
    a.set_title(n, fontsize=9); a.set_xlabel("Predicted"); a.set_ylabel("Actual")
plt.savefig(os.path.join(OUT, "confusion_matrices.png"), dpi=150, bbox_inches="tight"); plt.close()
print("\nDone. Artifacts saved in model/ and results/")
